# Assignment 1 – Implementation Notes

**File:** `assign_one_hermite.js`

This file contains all required functionality for the assignment.

---

## Core spline implementation
- Implemented a full **cubic Hermite spline** in `class HermiteSpline`.
- Global parameterization `t := [0,1]` is handled in `evaluate(t)` by:
  - mapping `t` to a segment index
  - converting to local `u := [0,1]`
  - scaling tangents correctly so interpolation is consistent across segments

See `HermiteSpline.evaluate(t)`

---

## Drawing the spline
- The spline is sampled and drawn **only when the Draw button is pressed**.
- Sampling is done in `update_scene()` using `this.spline.sample(40)`.
- The curve is rendered as a continuous **LINE_STRIP** via a custom `Polyline` shape.

See `update_scene()` and `class Polyline`

---

## Command parsing (text input)
- All text-based commands are handled in `parse_commands()`.
- Supports:
  - adding control points
  - editing points and tangents
  - computing arc length and printing a lookup table
- Errors are caught and reported in the output textbox.

See `parse_commands()`

---

## Arc length parameterization
- Arc length is approximated using piecewise linear sampling.
- A lookup table mapping `s -> t` is generated and printed.
- Used only for reporting (not for motion).

See `HermiteSpline.arc_length_table()`  
Triggered by `get_arc_length` inside `parse_commands()`

---

## Load / Export
- Implemented a simple text format loader/exporter for splines.
- Used to save and restore control points and tangents.

See:
- `HermiteSpline.load_from_string()`
- `HermiteSpline.export_to_string()`

---

## Preset shapes
- **Straight!** creates a straight Hermite spline with consistent tangents.
- **Circle!** creates a smooth closed loop using many control points and correctly scaled tangents.
- Both presets immediately redraw the spline.

See `preset_straight()` and `preset_circle()`

---

## IMPORTANT NOTE 
To avoid unintended interpolation artifacts:
> **Please reload the page before testing a new shape or input set.**

Because the spline state persists across button presses, mixing presets and manual commands without reloading can lead to confusing intermediate results. A fresh reload ensures clean, expected behavior. 
**Verified with the TA that this behavior is okay to submit.**

---

## How to quickly test
1. Reload page
2. Click **Straight!** or **Circle!**
3. Click **Draw**
4. **Or** Export -> Reload -> Load -> Draw


## Test cases (given by TA)

### Test Case 1
```
add point  0.0 4.0 0.0   -12.0  -3.0   12.0
add point  0.0 3.0 4.0     9.0  -3.0    9.0
add point  3.0 2.0 4.0     9.0  -3.0   -9.0
add point  3.0 1.0 0.0   -12.0  -3.0  -12.0
```

### Test Case 2
```
add point  0.0 5.0 0.0   -20.0  0.0   20.0
add point  0.0 5.0 5.0    20.0  0.0   20.0
add point  5.0 5.0 5.0    20.0  0.0  -20.0
add point  5.0 5.0 0.0   -20.0  0.0  -20.0
add point  0.0 5.0 0.0   -20.0  0.0   20.0
get_arc_length
```

### Note for Test Case 2
When inputing get_arc_length, I get the following `22.955834`
Compared to the `22.955833`, that the test case provides. This is due to a difference in sampling. **Note that the TA said that this difference
in approximation is so small that it does not matter.**
